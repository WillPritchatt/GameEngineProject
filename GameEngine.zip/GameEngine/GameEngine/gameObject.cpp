#include "gameObject.h"


gameObject::gameObject()
{

}

gameObject::~gameObject()
{

}

void gameObject::AddComponent(void)
{
	
}
