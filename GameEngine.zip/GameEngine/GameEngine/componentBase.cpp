#include "componentBase.h"

void componentBase::Update()
{
}

void componentBase::PhysUpdate()
{
}
