#pragma once
class componentBase
{
public:

	virtual void Update();

	virtual void PhysUpdate();
};

